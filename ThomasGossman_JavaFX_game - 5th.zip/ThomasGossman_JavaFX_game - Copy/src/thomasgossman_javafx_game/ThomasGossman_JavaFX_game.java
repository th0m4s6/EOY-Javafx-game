/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thomasgossman_javafx_game;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import java.util.ArrayList;
import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.scene.text.Text;
import javafx.event.ActionEvent;
import javafx.scene.shape.Shape;
import javafx.event.Event;
import javafx.geometry.Rectangle2D;
import javafx.scene.Node;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Ellipse;
import java.util.Random;
import static javafx.application.Application.launch;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Paint;
import javafx.scene.text.Font;

/**
 *
 * @author thomas
 */
public class ThomasGossman_JavaFX_game extends Application {

    Random placement = new Random();
    int e = placement.nextInt(600);
    int p = placement.nextInt(600);
    boolean letsplay = false;
    //arraylists

    ArrayList<Lava> hotrockz = new ArrayList();
    ArrayList<Rectangle> badblockz = new ArrayList();
    ArrayList<String> input = new ArrayList<String>();
    // ArrayList<Platform> plank = new ArrayList<Platform>();
    ArrayList<Lava> fire = new ArrayList<Lava>();
    ArrayList<Workbench> tabletop = new ArrayList<Workbench>();
    ArrayList<Workbench> tabletop2 = new ArrayList<Workbench>();
    ArrayList<Workbench> tabletop3 = new ArrayList<Workbench>();
    ArrayList<Lava> magma = new ArrayList<Lava>();

    door level1;
    door level2;
    door level3;
    Rectangle rect;
    Rectangle box;
    Rectangle bg;
    Rectangle bg2;
    Rectangle bg3;
    Rectangle bg4;
    Ellipse boi;
    Runner pete;
    Runner caleb;
    Runner don;
    Rectangle startscreen;
    Rectangle endscreen;
    Text deathmessage;
    Text winmessage;
    Text starttext;
    Text starttext2;
    Text starttext3;
    Rectangle winscreen;
    Teacher loomis;

    // add picture 
    /// add the image view 
    Canvas canvas;
    public Group win;
    public Group root;
    public Group death;
    public Group root2;
    public Group root3;

    @Override
    public void start(Stage primaryStage) {
        death = new Group();
        root2 = new Group();
        root = new Group();
        root3 = new Group();
        win = new Group();
        Scene scene = new Scene(root);
        primaryStage.setTitle("box check");
        primaryStage.setScene(scene);

        canvas = new Canvas(600, 600);
        Pane design = new Pane();
        StackPane holder = new StackPane();
        holder.getChildren().add(canvas);
        design.getChildren().add(holder);
        winscreen = new Rectangle(canvas.getHeight(), canvas.getWidth());
        winscreen.setFill(Color.BLACK);
        winmessage = new Text(100, 100, "you won! \n\n Look at \n\n Mr. Loomis \n\n he's so happy \n\n \n\n your prize is this picture");
        winmessage.setFill(Color.AQUA);
        winmessage.setFont(Font.font("TimesNewRoman", 24));

        startscreen = new Rectangle(canvas.getHeight(), canvas.getWidth());
        startscreen.setFill(Color.BURLYWOOD);

        endscreen = new Rectangle(canvas.getHeight(), canvas.getWidth());
        endscreen.setFill(Color.CADETBLUE);
        deathmessage = new Text(250, 100, "you died ! \n\n better luck \n\n next time");
        deathmessage.setFill(Color.CRIMSON);
        deathmessage.setFont(Font.font("Comicsans", 50));
        // instantiate picture
        //instantiate imageview 
        //Notice gc is not being used yet 
        GraphicsContext gc = canvas.getGraphicsContext2D();

        starttext = new Text(250, 100, "Press Y" + " to save Loomis \n\n oh yeah, the floor is lava \n\n so... save him and earn a prize");
        starttext.setFill(Color.BLACK);
        starttext.setFont(Font.font("Verdana", 20));
        starttext.setFill(Color.BLUE);
        starttext2 = new Text(390, 20, "level: 2");
        starttext2.setFill(Color.WHITE);
        starttext2.setFont(Font.font("Verdana", 20));
        starttext3 = new Text(390, 20, "level: 3");
        starttext3.setFill(Color.CADETBLUE);
        starttext3.setFont(Font.font("Verdana", 20));

        //notice we are creating shape objects 
        boi = new Ellipse(225, 225, 10, 10);
        bg = new Rectangle(0, 0, 600, 600);
        bg2 = new Rectangle(0, 0, 600, 600);
        bg3 = new Rectangle(0, 0, 600, 600);
        bg4 = new Rectangle(0, 0, 600, 600);
        loomis = new Teacher(275, 175, 160, 200);
        bg4.setFill(Color.IVORY);
        bg3.setFill(Color.LIGHTGREY);
        bg2.setFill(Color.DARKSLATEGRAY);
        bg.setFill(Color.DARKGREY);

        box = new Rectangle(300, 300, 23, 23);
        box.setFill(Color.PLUM);

        rect = new Rectangle(150, 50, 25, 25);
        rect.setFill(Color.BLUE);

        // notice the difference in how an ArrayList adds items 
        for (int h = 0; h < canvas.getWidth(); h += 30) {
            hotrockz.add(new Lava(h, 570));

        }
        for (int h = 0; h < canvas.getWidth(); h += 30) {
            fire.add(new Lava(h, 570));

        }
        for (int h = 0; h < canvas.getWidth(); h += 30) {
            magma.add(new Lava(h, 570));
        }
        tabletop.add(new Workbench(30, 500, 100, 15));
        tabletop.add(new Workbench(200, 450, 100, 15));
        tabletop.add(new Workbench(400, 300, 100, 15));
        tabletop.add(new Workbench(200, 150, 100, 15));
        tabletop.add(new Workbench(75, 50, 100, 15));
        tabletop2.add(new Workbench(150, 450, 100, 15));
        tabletop2.add(new Workbench(300, 250, 100, 15));
        tabletop2.add(new Workbench(250, 100, 100, 15));
        tabletop2.add(new Workbench(100, 450, 100, 15));
        tabletop3.add(new Workbench(100, 450, 100, 15));
        tabletop3.add(new Workbench(200, 350, 100, 15));
        tabletop3.add(new Workbench(200, 250, 100, 15));
        tabletop3.add(new Workbench(500, 250, 100, 15));
        tabletop3.add(new Workbench(500, 150, 100, 15));

        pete = new Runner(100, 25, 300);
        caleb = new Runner(100, 25, 300);
        don = new Runner(100, 25, 300);
        level1 = new door(50, 100, 40, 40);
        level2 = new door(50, 75, 40, 40);
        level3 = new door(500, 20, 40, 40);

        //we have created an animation timer --- the class MUST be overwritten - look below 
        AnimationTimer timer = new MyTimer();

        scene.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override

            public void handle(KeyEvent event) {
                if (event.getCode() == KeyCode.R && pete.health == 0) {
                    //  pete.health = 90; 
                    scene.setRoot(root);
                }
                if (!letsplay) {

//                 //   starttext = new Text(canvas.getHeight() / 2, canvas.getWidth(), "Press D");
//                    starttext.setFill(Color.BLACK);
//                    starttext.setFont(Font.font("Verdana", 20));
//                    starttext.setFill(Color.RED);
                }

                if (event.getCode() == KeyCode.Y) {
                    starttext.setText("level: 1");
                    starttext.setX(390);
                    starttext.setY(20);
                    starttext.setFill(Color.BLACK);
                    letsplay = true;
                    startscreen.setWidth(0);
                    startscreen.setHeight(0);

                }

                if (letsplay) {
                    //  starttext.setText("");
                    //String code = event.getCode().toString();
                    //    input.remove( code );

                    if (pete.x > 0 && event.getCode() == KeyCode.A || event.getCode() == KeyCode.LEFT) { // don't use toString here!!!
                        pete.moveLeft();
                        if (pete.level == 2) {
                            caleb.moveLeft();
                        }
                        if (pete.level == 3) {
                            don.moveLeft();
                        }

//                        caleb.moveLeft();
//                        don.moveLeft();
                        box.setFill(Color.CADETBLUE);

                        // System.out.println("Going left");
                    }

                    if (event.getCode() == KeyCode.D || event.getCode() == KeyCode.RIGHT && pete.x < 600) {
                        pete.moveRight();
                        if (pete.level == 2) {
                            caleb.moveRight();
                        }
                        if (pete.level == 3) {
                            don.moveRight();
                        }
                        box.setFill(Color.RED);

                    }

                    if (event.getCode() == KeyCode.W || event.getCode() == KeyCode.UP && pete.y > 0 || event.getCode() == KeyCode.SPACE) {
                        pete.hop = pete.hop + 1;

                        pete.moveUp();
                        if (pete.level == 2) {
                            caleb.moveUp();
                            caleb.hop = caleb.hop + 1;
                        }
                        if (pete.level == 3) {
                            don.moveUp();
                            don.hop = don.hop + 1;
                        }
                        box.setFill(Color.GREEN);

                    }

                    if (event.getCode() == KeyCode.S || event.getCode() == KeyCode.DOWN) {
                        pete.moveDown();
                        caleb.moveDown();
                        don.moveDown();
                        box.setFill(Color.ORANGE);

                    }
                    if (pete.health == 0) {
                        scene.setRoot(death);
                    }
                    if (don.health == 0) {
                        scene.setRoot(death);
                    }
                    if (caleb.health == 0) {
                        scene.setRoot(death);
                    }
                    if (pete.level == 2) {
                        scene.setRoot(root2);
                        starttext.setText("level: 2");
                        starttext.setX(390);
                        starttext.setY(20);
                        starttext.setFill(Color.WHITE);
                    }
                    if (caleb.health == 0) {
                        scene.setRoot(death);
                    }
                    if (pete.level == 3) {

                        scene.setRoot(root3);
                    }
                    if (pete.level == 4) {
                        scene.setRoot(win);

                    }
                    if (don.health == 0) {
                        scene.setRoot(death);

                    }

                }
            }
        });

//        scene.setOnKeyReleased(new EventHandler<KeyEvent>() {
//            @Override
//            public void handle(KeyEvent event) {
//                if (event.getCode() == KeyCode.RIGHT || event.getCode() == KeyCode.LEFT) {
//                    // rectangleVelocity.set(0);
//                }
//            }
//        });
        //try disabling canvas --- notice the difference 
        root.getChildren().add(canvas);
        //notice we are manually adding the shape objects to the "root" window

//        for (Lava l : hotrockz) {
//
//            root.getChildren().add(l);
//        }
        root.getChildren().add(bg);
        root2.getChildren().add(bg2);
        root3.getChildren().add(bg3);
        win.getChildren().add(winscreen);
        win.getChildren().add(winmessage);
        root.getChildren().add(pete.picture);
        root2.getChildren().add(caleb.picture);
        root3.getChildren().add(don.picture);
        root.getChildren().add(level1.picture);
        root2.getChildren().add(level2.picture);
        root3.getChildren().add(level3.picture);
        win.getChildren().add(loomis.picture);
        root2.getChildren().add(starttext2);
        root3.getChildren().add(starttext3);

        for (Lava l : hotrockz) {

            root.getChildren().add(l.picture);
        }

        for (Workbench w2 : tabletop2) {
            root2.getChildren().add(w2.picture);
        }

        for (Workbench w : tabletop) {
            root.getChildren().add(w.picture);
        }
        for (Workbench w : tabletop3) {
            root3.getChildren().add(w.picture);
        }
        for (Lava l : fire) {
            root2.getChildren().add(l.picture);
        }
        for (Lava l : magma) {
            root3.getChildren().add(l.picture);
        }

        root.getChildren().add(startscreen);
        root.getChildren().add(starttext);

        death.getChildren().add(endscreen);
        death.getChildren().add(deathmessage);
        timer.start();
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     *
     * The same as before main just calls the args described above
     */
    ///  vvvvvvvvvvvv   MAIN vvvvvvvvvvv
    public static void main(String[] args) {
        launch(args);
    }

    //// ^^^^^^^^^^^  MAIN ^^^^^^^^^^^^^
    // we create our time here --- to animate 
    private class MyTimer extends AnimationTimer {

        boolean movedown = true;

        /// handle is defined by the abstract parent class -- it must be redined 
        /// this is what happens again and again until stop()
        @Override
        public void handle(long now) {

//            pete.moveRight();
//            pete.moveLeft();
//            pete.moveUp();
//            pete.moveDown();
//            pete.walkOutside();
            pete.fall();

            if (pete.level == 2) {
                caleb.fall();
            }
            if (pete.level == 3) {
                don.fall();

            }

            // You can look at the key presses here as well -- this is one of many. Try others
//            if (input.contains("LEFT")) {
//                box.setX(box.getX() - 5);
//            }
            doHandle();
            /// notice doHandle()  is what happens again and again it's defined below

        }

        private void doHandle() {

//       for(WorkbencArrayList<Lava> hotrockz = new ArrayList();h w : tabletop){
//          if(pete.x != tabletop.x3 && pete.y != tabletop.y3 ){
//              pete.moveDown();
//          }
//       }\
//              if (!pete.alive) {
//            //add image view to root 
//            scene.setRoot(death);
//            }
            for (Lava l : hotrockz) {
                if (pete.getBoundsInParent().intersects(l.getBoundsInParent())) {

                    pete.health = 0;

                }
                for (Lava l3 : fire) {
                    if (caleb.getBoundsInParent().intersects(l3.getBoundsInParent())) {
                        caleb.health = 0;

                    }
                }
                for (Lava l2 : magma) {
                    if (don.getBoundsInParent().intersects(l2.getBoundsInParent())) {
                        don.health = 0;
                    }

                }
                if (pete.getBoundsInParent().intersects(level1.getBoundsInParent())) {
                    pete.level = 2;
//                  for (Workbench w : tabletop) {
//                root.getChildren().remove(w);
//                  }
                }
                if (caleb.getBoundsInParent().intersects(level2.getBoundsInParent())) {
                    pete.level = 3;
                }

            }

            if (don.getBoundsInParent().intersects(level3.getBoundsInParent())) {
                pete.level = 4;
            }

//
//            if (movedown && rect.getY() < 555) {
//                rect.setY(rect.getY() + .5);
//            }
//            if (!movedown && rect.getY() > 1) {
//                rect.setY(rect.getY() - .5);
//            }
//            if (rect.getY() > 550) {
//                movedown = false;
//            }
//            if (rect.getY() < 1) {
//                movedown = true;
//            }
            // stop();
            // System.out.println("Animation stopped");
        }
    }

    class Runner extends Rectangle {

        int hop = 0;
        int health = 1;
        double x, y;
        int level = 1;
        public Rectangle myrect;
        public boolean alive = true;
        boolean canRight = true;
        public boolean canLeft = true; //that's tough 
        boolean canUp = true;
        boolean canDown = true;
        boolean fallDown = true;
        boolean jump = true;
        Image petepic = new Image("file:src/pete.png ");
        public ImageView picture = new ImageView(petepic);

        public Runner(int health, int x, int y) {

            this.health = 1;
            this.x = x;
            this.y = y;
            this.setX(x);
            this.setY(y);
            myrect = new Rectangle(x, y, 25, 25);
            myrect.setFill(Color.BROWN);
            alive = true;
            this.picture.setX(x);
            this.picture.setY(y);
            this.picture.setFitHeight(30);
            this.picture.setFitWidth(30);
            this.canLeft = true;
            this.alive = true;

        }

        public void moveRight() {
            if (this.x <= 600) {
                this.setX(this.getX() + 30);
                //this.picture.setY(this.getY());
                myrect.setX(this.getX());
                //  System.out.println("going right");

                this.picture.setX(this.getX());
                this.picture.setY(this.getY());
            }

        }

        public void moveLeft() {
            if (this.x >= 0) {
                this.setX(this.getX() - 30);
                myrect.setX(this.getX());
                this.picture.setX(this.getX());
                this.picture.setY(this.getY());
                //   System.out.println("going left");
            }

        }

        public void moveUp() {

            if (this.hop < 3) {
                this.setY(this.getY() - 150);
                myrect.setY(this.getY());
                this.picture.setX(this.getX());
                this.picture.setY(this.getY());
                //   System.out.println("going up");
                //    System.out.println(this.x);
            }

        }

        public void moveDown() {
            //  pete.moveDown();
//            if (fallDown = true) {
//                pete.moveDown();
//            } else if (pete.getBoundsInParent().intersects(w.getBoundsInParent())) {
//                fallDown = false;
//            }

            this.setY(this.getY() + .25);
            if (this.getY() < 580) {
                //      this.setY(this.getY() + .15);
                if (!this.amItochingsomethingDown()) {
                    myrect.setY(this.getY());
                    this.picture.setX(this.getX());
                    this.picture.setY(this.getY());
                    //   System.out.println("going down  my falldown " + this.fallDown);
                } else {
                    this.setY(this.getY() - .15);
                    this.fallDown = false;
                    //    System.out.println("mah health " + pete.health);
                    //     System.out.println("Let's stop " + this.fallDown);
                }
            }
        }

//        public void down() {
//
//            this.setY(this.getY() + .25);
//            this.picture.setX(this.getX());
//            this.picture.setY(this.getY());
//        }
        public void walkOutside() {
            if (this.x <= 0) {
                this.x = 600;
            }
            if (this.x >= 600) {
                this.x = 10;
            }
            this.picture.setX(this.getX());
            this.picture.setY(this.getY());
        }

        public void fall() {

            if (this.fallDown) {
                this.moveDown();
            }
            if (this.amItochingsomethingDown()) {
                this.fallDown = false;
            } else {
                this.fallDown = true;
            }
//            this.picture.setX(this.getX());
//            this.picture.setY(this.getY());
        }

        private boolean amItochingsomethingDown() {
            // checkBounds is called in two different locaRectangle tions --- it's really only necessary in the animation dohandle
            // experiment - check the differences

            boolean collisionDetected = false;

            // notice the difference in how an ArrayList iterates through items 
            for (Workbench w : tabletop) {
                if (caleb.getBoundsInParent().intersects(w.getBoundsInParent())) {
                    caleb.fallDown = true;
                    collisionDetected = false;

                }
                if (pete.getBoundsInParent().intersects(w.getBoundsInParent())) {
                    pete.fallDown = false;
                    //     this.goDown = false;
                    collisionDetected = true;
                    //         System.out.println("hit the floor");
                    pete.hop = 0;
                }

            }
            for (Workbench w2 : tabletop2) {
                if (caleb.getBoundsInParent().intersects(w2.getBoundsInParent())) {

                    caleb.fallDown = false;
                    //     this.goDown = false;
                    collisionDetected = true;
                    //         System.out.println("hit the floor");
                    caleb.hop = 0;
                }

            }
            for (Workbench w3 : tabletop3) {
                if (don.getBoundsInParent().intersects(w3.getBoundsInParent())) {

                    don.fallDown = false;
                    //     this.goDown = false;
                    collisionDetected = true;
                    //         System.out.println("hit the floor");
                    don.hop = 0;
                }

            }

            return collisionDetected;
        }

    }

    /*class Platform extends Rectangle {
    int l, w;
    double x, y;
    
    
    

}*/
    class Lava extends Rectangle {

        double x2, y2;
        double l, w;
        Image lavapic = new Image("file:src/lava.png ");
        public ImageView picture = new ImageView(lavapic);

        public Lava(double x, double y) {
            super(x, y, 30, 30);
            this.setFill(Color.TRANSPARENT);
            this.l = 30;
            this.w = 30;
            this.x2 = x;
            this.y2 = y;
            this.picture.setX(this.getX());
            this.picture.setY(this.getY());
            this.picture.setFitHeight(30);
            this.picture.setFitWidth(30);
        }

    }

    class Workbench extends Rectangle {

        Image toppic = new Image("file:src/oakplanks.png ");
        public ImageView picture = new ImageView(toppic);

        double x3, y3, l1, w1;

        public Workbench(double x, double y, double width, double height) {
            super(x - 15, y, width + 15, height);
            this.x3 = x;
            this.y3 = y;
            //  this.l1 = width;
            //    this.w1 = height;
            // this.setFill(Color.BLACK);
            this.setFill(Color.BLACK);
            this.picture.setX(this.x3);
            this.picture.setY(this.y3 + 30);
            this.picture.setFitHeight(height);
            this.picture.setFitWidth(width);
        }

    }

    class door extends Rectangle {

        double x, y;
        int w, l;
        Image portal = new Image("file:src/nether.png");
        public ImageView picture = new ImageView(portal);

//        public door(double width, double height) {
//            super(width, height);
//            this.x = x;
//            this.y = y;
//           cx
//        }
        public door(double x, double y, double width, double height) {
            super(x, y, width, height);
            this.picture.setX(x);
            this.picture.setY(y);
            this.picture.setFitHeight(40);
            this.picture.setFitWidth(40);
        }

    }
}

class Teacher extends Rectangle {

    Image prize = new Image("file:src/Loomis.jpeg");
    public ImageView picture = new ImageView(prize);

    public Teacher(double x, double y, double width, double height) {
        super(x, y, width, height);
        this.picture.setX(x);
        this.picture.setY(y);
        this.picture.setFitHeight(height);
        this.picture.setFitWidth(width);
    }

}
